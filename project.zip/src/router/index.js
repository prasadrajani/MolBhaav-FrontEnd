import Vue from 'vue'
import Router from 'vue-router'
// import HelloWorld from '@/components/HelloWorld'
import header from '@/components/Header'
import Signin from '@/components/SignIn'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Header',
      component: header
    },
    {
      path: '/Signin',
      name: 'Signin',
      component: Signin
    }
  ]
})

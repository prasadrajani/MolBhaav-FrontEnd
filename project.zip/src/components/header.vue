<template>
  <div>
    <v-toolbar dark fixed>
    <v-toolbar-side-icon></v-toolbar-side-icon>
    <v-toolbar-title>Covimart</v-toolbar-title>
    <v-spacer></v-spacer>
    <v-toolbar-items class="hidden-sm-and-down">
      <v-flex xs12 sm6 md8>
          <v-text-field
            placeholder="Search"
          ></v-text-field>
        </v-flex>
      <v-btn flat>
        <v-btn icon>
              <v-icon>search</v-icon>
        </v-btn>
      </v-btn>
      <v-btn flat icon router-link to="/signin" target="-blank">Sign-in</v-btn>
      <v-btn flat icon router-link to="/signup" target="-blank">Sign-up</v-btn>
    </v-toolbar-items>
  </v-toolbar>
  </div>
</template>

<<script>
  export default{
    name: 'header'
  }
</script>

<template>
<div>
  <router-view/>
  <header></header>
  </div>
</template>>

<script>
import header from '@/components/header'
  export default{
    name: 'App',
    components: {
      header
    }
  }
</script>>
